package challenges;

import com.github.javafaker.Faker;

public class FakerData {



	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Faker fake = new Faker();		
		String userName = fake.name().username();
		System.out.println(userName);
		String firstName = fake.name().firstName();
		System.out.println(firstName);
		String lastName = fake.name().lastName(); 
		System.out.println(lastName);
		String emailAddress = firstName + lastName + "@test.com";
		System.out.println(emailAddress);
		String buildingNumber = fake.address().buildingNumber();
		String city = fake.address().city();
		String country = fake.address().country();
		String countryCode = fake.address().countryCode();
		
		System.out.println(buildingNumber +" ,"+city );
		System.out.println(country +"-"+countryCode);
		
		
	}

}
