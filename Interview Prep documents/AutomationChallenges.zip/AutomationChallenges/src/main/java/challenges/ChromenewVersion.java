package challenges;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class ChromenewVersion {

	public static void main(String[] args) {
	//to automate the application in chrome for testing browser (cft browser)
		ChromeOptions options = new ChromeOptions();
		options.setBinary("115");
		ChromeDriver driver=new ChromeDriver(options);
		driver.get("http://leaftaps.com/opentaps");
		System.out.println(driver.getTitle());
		//driver.close();

	}

}
