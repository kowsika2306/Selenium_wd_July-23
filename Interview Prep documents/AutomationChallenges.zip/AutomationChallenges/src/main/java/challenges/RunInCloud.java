package challenges;

import java.io.IOException;

import java.net.URL;
import java.util.HashMap;

import org.openqa.selenium.By;

import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.RemoteWebDriver;

public class RunInCloud {

	public static void main(String[] args) throws IOException {

		ChromeOptions browserOptions = new ChromeOptions();
		browserOptions.setPlatformName("Windows 10");
		browserOptions.setBrowserVersion("115.0");
		HashMap<String, Object> ltOptions = new HashMap<String, Object>();
		ltOptions.put("username", "vidyar1926");
		ltOptions.put("accessKey", "xqHmrSa12TjL04iSMDva7kF07xB1ElHQWuIjm7u5oa3JJFbXRl");
		ltOptions.put("visual", true);
		ltOptions.put("project", "Leaftaps");
		ltOptions.put("selenium_version", "4.0.0");
		ltOptions.put("w3c", true);
		browserOptions.setCapability("LT:Options", ltOptions);
		URL url = new URL(
				"https://vidyar1926:xqHmrSa12TjL04iSMDva7kF07xB1ElHQWuIjm7u5oa3JJFbXRl@hub.lambdatest.com/wd/hub");

		RemoteWebDriver driver = new RemoteWebDriver(url, browserOptions);

		driver.manage().window().maximize();
		driver.get("http://leaftaps.com/opentaps/control/main");
		driver.findElement(By.id("username")).sendKeys("demosalesmanager");
		driver.findElement(By.id("password")).sendKeys("crmsfa");
		driver.findElement(By.className("decorativeSubmit")).click();

	}

}
