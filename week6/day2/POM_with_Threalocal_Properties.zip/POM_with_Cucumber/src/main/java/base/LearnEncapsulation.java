package base;

public class LearnEncapsulation {

	
	private String Pwd="123Vid";
	
	private int number;
	//private variables -->getter and setter 
	
	public String getPwd() {
		return Pwd;
	}
		
	
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}






	
  
	
}
