package base;

public class LearntoUsePrivateVariables extends LearnEncapsulation {

	public static void main(String[] args) {
		LearntoUsePrivateVariables ob=new LearntoUsePrivateVariables();
	     String pwd = ob.getPwd();
	     System.out.println(pwd);
		
	}
	
}
