package configProperties;

import org.aeonbits.owner.ConfigCache;

public class Configuration {

	//user defined class -->create a method
		
	
	public static ConfigurationManager configmanager() {
		return ConfigCache.getOrCreate(ConfigurationManager.class);
	}
}
