package configProperties;

import org.aeonbits.owner.Config;

@Config.Sources({"classpath:config.properties"})
public interface ConfigurationManager extends Config {
		//user defined Interface
		//key value pair
	
	
	@Key("username")
	String getUsername();

	
	@Key("timeout")
	int timeOut();
}

