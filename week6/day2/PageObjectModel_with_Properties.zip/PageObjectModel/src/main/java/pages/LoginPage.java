package pages;

import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods{
	
	public LoginPage(ChromeDriver driver,Properties prop) {
		this.driver=driver;
		this.prop=prop;
	}	

	public LoginPage enterUsername() {
		driver.findElement(By.id("username")).sendKeys(prop.getProperty("username"));
		//LoginPage lp=new LoginPage();
		//return new LoginPage();
		return this; //this represents the current class object/constructor
	}

	public LoginPage enterPassword() {
		driver.findElement(By.id("password")).sendKeys(prop.getProperty("password"));
		//LoginPage lp=new LoginPage();
		//return new LoginPage();
		return this;
	}

	public WelcomePage clickLogin() {
		driver.findElement(By.className("decorativeSubmit")).click();
	//	WelcomePage wp=	new WelcomePage();
		return 	new WelcomePage(driver,prop);
	}

}
