package testcase;

import java.io.IOException;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;

public class TC002_CreateLead extends ProjectSpecificMethods{
	
	@BeforeClass
	public void setValues() {
		filename="Lead";
		testName="CreateLead Funtionality";
		testDesc="Lead with Mandatory data";
		author="Subash";
		category="Functional Testing";

	}

	@Test(dataProvider ="sendData")
	public void runCreate(String cname,String fname,String lname) throws IOException {
		
		
		new LoginPage(driver).enterUsername().enterPassword().clickLogin().clickCRMSFA()
		.clickLeads().clickCreateLead().enteCompanyName(cname).enterFirstName(fname).enterLastname(lname)
		.clickCreateButton().verifyFirstname();
		
	}
	
}
