package testcase;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;
import pages.WelcomePage;

public class TC001_Login extends ProjectSpecificMethods{
	@BeforeTest
	public void setValues() {
		testName="Login functionality";
		testDesc="Login with valid Credentials";
		author="Sindhuja";
		category="Smoke Testing";
	}
	
	@Test
	public void runLogin() throws IOException {
		
		LoginPage lp=new LoginPage(driver);
		lp.enterUsername().enterPassword().clickLogin().verifyWelcomePage();
		
		
		//@BeforeMethod --->@Test-->pages(LoginPage) -->flow
		/*
		 * lp.enterUsername(); lp.enterPassword(); lp.clickLogin();
		 * 
		 * 
		 * WelcomePage wp=new WelcomePage(); wp.clickCRMSFA();
		 */
		
	}

}
