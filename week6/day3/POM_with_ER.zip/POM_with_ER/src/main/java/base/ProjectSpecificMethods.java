package base;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import utils.ReadExcel;

public class ProjectSpecificMethods {

	public RemoteWebDriver driver;
	public String filename;
	public ExtentReports extent;
	public String testName, testDesc, author, category;
	public static ExtentTest test;

	@BeforeSuite
	public void startReport() {
		ExtentHtmlReporter reporter = new ExtentHtmlReporter("./reports/result.html");
		reporter.setAppendExisting(true);
		extent = new ExtentReports();
		extent.attachReporter(reporter);
	}
	@BeforeClass
	public void testDetails() {
		test = extent.createTest(testName, testDesc);
		test.assignAuthor(author);
		test.assignCategory(category);
	}
	public void reportStep(String status, String message) throws IOException {
		// condition
		if (status.equalsIgnoreCase("pass")) {
			test.pass(message,
				MediaEntityBuilder.createScreenCaptureFromPath(".././snap/pic" + takeSnap() + ".jpg").build());
		} else {
			test.fail(message,
					MediaEntityBuilder.createScreenCaptureFromPath(".././snap/pic" + takeSnap() + ".jpg").build());
			throw new RuntimeException("Check the reporter");
		
		}

	}

	public int takeSnap() throws IOException {
		int random = (int) (Math.random() * 999);
		File source = driver.getScreenshotAs(OutputType.FILE);
		File destn = new File("./snap/pic" + random + ".jpg");
		FileUtils.copyFile(source, destn);
		return random;
	}

	@Parameters({ "browser", "url" })
	@BeforeMethod
	public void preCondition(String browser, String url) {
		if (browser.equalsIgnoreCase("chrome")) {
			driver = new ChromeDriver();
		} else if (browser.equalsIgnoreCase("edge")) {
			driver = new EdgeDriver();
		}
		driver.manage().window().maximize();
		driver.get(url);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
	}
	// from xml-->@BeforeTest -->@DataProvider
	// -->@BeforeMethod-->@Test-->@AfterMethod

	@AfterMethod
	public void postConditions() {
		driver.close();
	}

	@DataProvider
	public String[][] sendData() throws IOException {

		// Creating object for the class ReadExcel ->call the readExcel()
		ReadExcel re = new ReadExcel();
		String[][] data = re.readExcel(filename);
		return data;

	}

	@AfterSuite
	public void endReport() {
		extent.flush();
	}

}
