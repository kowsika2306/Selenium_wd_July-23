package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods {

	public LoginPage(RemoteWebDriver driver) {
		this.driver = driver;
	}

	public LoginPage enterUsername() throws IOException {
		try {
			driver.findElement(By.id("username")).sendKeys("demoSalesManager");
			reportStep("pass", "Username is entered successfully");
		} catch (Exception e) {
			reportStep("fail", "Username is not entered successfully");

		}
		return this; // this represents the current class object/constructor
	}

	public LoginPage enterPassword() throws IOException {
		try {
			driver.findElement(By.id("passwor")).sendKeys("crmsfa");
			reportStep("pass", "Password is entered successfully");
		} catch (Exception e) {
			reportStep("fail", "Password is not entered successfully " + e.getMessage());

		}
		return this;
	}

	public WelcomePage clickLogin() throws IOException {
		try {
			driver.findElement(By.className("decorativeSubmit")).click();
			reportStep("pass", "Login button is clicked successfully");
		} catch (Exception e) {
			reportStep("fail", "Login button is not clicked successfully" + e.getMessage());

		}
		// WelcomePage wp= new WelcomePage();
		return new WelcomePage(driver);
	}

}
